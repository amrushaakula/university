# UNIVERSITY MANAGEMENT – University Academic Management System

A simple browser-based academic management project for students, faculty and admin.

## Login options

### Admin
- Username: `admin`
- Password: `admin123`
- Access: Dashboard, Students, Faculty, Departments, Courses, Attendance, Marks, Examinations
- Can add and delete records.

### Faculty
- Username: `faculty`
- Password: `faculty123`
- Access: Dashboard, Students, Courses, Attendance, Marks, Examinations
- Can add and delete records.

### Student
- Username: `student`
- Password: `student123`
- Access: Dashboard, Courses, Attendance, Marks, Examinations
- Read-only access.

## How to run
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge or another modern browser.
3. Select Admin, Faculty or Student.
4. Enter the demo username and password.
5. Use Logout to return to the login screen.

## Features
- Role-based login
- Student, Faculty and Admin access
- Student/faculty/course/department management
- Attendance, marks and examination records
- Add/delete records for Admin and Faculty
- Student read-only access
- Browser localStorage for saving project data
- Responsive design
